# library(shiny)
# setwd("~/git/insightrx/ucsf-tbsim-shiny/app")
PORT <- 1410
if(Sys.getenv("PORT") != "") PORT <- as.numeric(as.character(Sys.getenv("PORT")))
shiny::runApp("./", launch.browser=T, port=PORT)
