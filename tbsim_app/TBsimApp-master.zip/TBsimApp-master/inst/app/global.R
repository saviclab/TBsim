## TBsim libraries
library(TBsimApp)       ## Helper functions for the TBsim Shiny app
library(TBsim)          ## Main simulation module

## Custom libraries
library(PKPDsim)        ## Simulation
library(PKPDplot)       ## Plotting
library(vpc)            ## For some plotting functions
library(insightrxmisc)  ## Miscellaneous routines, will be split off later
library(Rge)            ## Grid engine

## tidyverse and related
library(stringr)        ## String manipulation
library(lubridate)      ## For handling date/times
library(anytime)        ## parse dates and times
library(ggplot2)

# library(sys)            ## run internal system commands

################################################################
## Google authentication
################################################################
library(googleAuthR)
library(googleID)
library(shiny)
library(shinyjs)
library(rhandsontable)
library(jsonlite)

# library(shinyjs)
options(googleAuthR.scopes.selected = c("https://www.googleapis.com/auth/userinfo.email", "https://www.googleapis.com/auth/userinfo.profile"))
options(googleAnalyticsR.webapp.client_id = "241562557063-g9lbe0soarkav0r91cts16s3vbfbu8e2.apps.googleusercontent.com")
options(googleAnalyticsR.webapp.client_secret = "b02s81PH-Yu3-ysTMAKh9z1F")
options(googleAuthR.client_id = "241562557063-g9lbe0soarkav0r91cts16s3vbfbu8e2.apps.googleusercontent.com")
options(googleAuthR.client_secret = "b02s81PH-Yu3-ysTMAKh9z1F")
options(googleAuthR.webapp.client_id = "241562557063-g9lbe0soarkav0r91cts16s3vbfbu8e2.apps.googleusercontent.com")
options(googleAuthR.webapp.client_secret = "b02s81PH-Yu3-ysTMAKh9z1F")

## Global variables and definitions
base_dir <- getwd()
regimenList <- list(
 "HRZE daily 8 wks, HR daily 18 wks" = tb_read_init("standard_HRZE8_7wkl_HR18_7wkl.txt"),
 "HRZE daily 8 wks, HR 3x/week 18 wks" = tb_read_init("standard_HRZE8_7wkl_HR18_3wkl.txt"),
 "HRZE 3x/week 8 wks, HR 3x/week 18 wks" = tb_read_init("standard_HRZE8_3wkl_HR18_3wkl.txt"),
 "HRZE daily 2 wks, HRZE 2x/wk 6 wks, HR 2x/week 18 wks" = tb_read_init("standard_HRZE2_7wkl_HRZE6_2wkl_HR18_2wkl.txt")
)
defaultRegimen <- names(regimenList)[1]
drugDefinitions <- list(
  RIF = tb_read_init("RIF.txt"),
  INH = tb_read_init("INH.txt"),
  PZA = tb_read_init("PZA.txt"),
  RPT = tb_read_init("RPT.txt"),
  MOX = tb_read_init("MOX.txt"),
  EMB = tb_read_init("EMB.txt")
)
drugNames <- list(
  RIF = "rifampicin",
  INH = "isoniazid",
  PZA = "pyrazinamide",
  RPT = "rifapentin",
  MOX = "moxonidine",
  EMB = "ethambutol"
)
adherenceOptions <- c("100%", "MEMS", "Markov")

## Colors
allDrugs <- drugDefinitions
allDrugs$Immune <- "dummy"
cols <- RColorBrewer::brewer.pal(length(allDrugs), "Dark2")
regimenColors <- list()
for(i in seq(names(allDrugs))) {
  regimenColors[[names(allDrugs)[i]]] <- cols[i]
}
regimenColors <- unlist(regimenColors, use.names=TRUE) ## ggplot2 doesn't take lists but insists on named vector

cache <<- list(
  resetRegimen = FALSE,
  regimenList = regimenList,
  defaultRegimen = defaultRegimen,
  combinedDrugList = names(allDrugs)
)

# Override shiny button, should be <button>, not <a>
downloadButtonPDF <- function(outputId,
                           label="Download",
                           class=NULL, ...) {
  aTag <- tags$a(id=outputId,
                 class=paste('btn btn-default shiny-download-link', class),
                 href='',
                 target='_blank',
                 download=NA,
                 icon("file-pdf-o"),
                 "", ...)
}
downloadButtonData <- function(outputId,
                           label="Download",
                           class=NULL, ...) {
  aTag <- tags$a(id=outputId,
                 class=paste('btn btn-default shiny-download-link', class),
                 href='',
                 target='_blank',
                 download=NA,
                 icon("download"),
                 "", ...)
}
