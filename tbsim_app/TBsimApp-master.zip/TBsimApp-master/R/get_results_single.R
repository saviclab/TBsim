#' Get results for single simulation
#'
#' @export
get_results_single <- function() {
  res <- get_sim_results_list(user = init$userId, type="single")
  dat <- pluck(res, 'datetime')
  if(length(dat)>0) {
    tab <- data.frame(cbind(
      Run = pluck(res, 'id'),
      Description = pluck(res, 'description'),
      Status = pluck(res, 'status')))
    tab$ago <- time_to_ago(dat, sort=FALSE, to_character = FALSE)
    tab$Finished <- time_to_ago(dat, sort=FALSE, to_character = TRUE)
    tab <- tab[order(tab$ago),]
    tab <- tab %>% filter(Status == "finished")
    tab[,c("Run", "Description", "Finished")]
  }
}
