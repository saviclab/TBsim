#' Get results for population simulation
#' @export
get_results_population <- function() {
  res <- get_sim_results_list(user = init$userId, type="population")
  tab <- data.frame(cbind(Run = pluck(res, 'id'), Description = pluck(res, 'description'), Status = pluck(res, 'status')))
  tab <- tab %>% filter(Status == "finished")
  tab
}
