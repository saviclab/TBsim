# TBsim App

Shiny app for simulation of TB regimens, for UCSF / TBTC
